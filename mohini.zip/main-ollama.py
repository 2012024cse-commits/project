from langchain_ollama import ChatOllama

llm=ChatOllama(
    model="llama3.2:latest",
    temparature=0.7,
)

response = llm.invoke("Give javascript code for my student management system")
print(response.content)
